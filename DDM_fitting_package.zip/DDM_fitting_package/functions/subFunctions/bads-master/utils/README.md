# Utility functions

This folder contains a number of utility functions used by BADS.
